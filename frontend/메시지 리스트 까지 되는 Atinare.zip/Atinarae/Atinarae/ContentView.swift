//
//  ContentView.swift
//  Atinarae
//
//  Created by HyunwooPark on 2023/04/30.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView{
            VStack {
//                NavigationLink(destination: UserDetailView(), label: {
//                    Text("아빠")
//                })
            }
            .padding()
        }
    }
}

//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}
